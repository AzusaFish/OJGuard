"""FastAPI application for OJGuard."""
